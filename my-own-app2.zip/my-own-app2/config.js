export const firebaseConfig = {
    apiKey: "AIzaSyAo0Lk8gbynw3Ty5itglPL2WmjR-IMdd10",
    authDomain: "story-telling2-ee6ef.firebaseapp.com",
    databaseURL: "https://story-telling2-ee6ef-default-rtdb.firebaseio.com",
    projectId: "story-telling2-ee6ef",
    storageBucket: "story-telling2-ee6ef.appspot.com",
    messagingSenderId: "691538144245",
    appId: "1:691538144245:web:961cb9b4d3ea602d444ebc"
  };
// databaseURL: "https://story-telling1-336ad-default-rtdb.firebaseio.com",